import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

export default function Header({ onOpenAuth }) {
  const { user, logout } = useContext(AuthContext);
  return (
    <header>
      <div className="brand">
        <div style={{ fontSize: 22 }}>🎨</div>
        <h1 onClick={() => document.querySelector('a[href="#home"]').click()}>Colorify</h1>
      </div>
      <nav>
        <a href="#home" className="active">Home</a>
        <a href="#saved">Saved</a>
        <a href="#about">About</a>
        <a href="#contact">Contact</a>
      </nav>
      <div>
        {!user ? (
          <button id="loginBtn" className="auth-btn" onClick={onOpenAuth}>Login / Signup</button>
        ) : (
          <button id="logoutBtn" className="auth-btn" onClick={logout}>Logout</button>
        )}
      </div>
    </header>
  );
}