import React, { useEffect, useState, useRef, useContext } from 'react';
import Header from '../components/Header';
import { AuthContext } from '../context/AuthContext';

/* Home contains the Colorify UI and logic ported from your static file */
export default function Home() {
  const { user } = useContext(AuthContext);
  const [currentColors, setCurrentColors] = useState([]);
  const [copiedColors, setCopiedColors] = useState([]);
  const [paletteName, setPaletteName] = useState('— • NUDE • —');
  const [quickVisible, setQuickVisible] = useState(false);
  const [contrastVisible, setContrastVisible] = useState(false);
  const [uploadMsg, setUploadMsg] = useState('');
  const uploadInputRef = useRef(null);

  const NAMES = ["NUDE","SAND & STONE","SUNSET GLOW","OCEAN MIST","FOREST CALM","BLUSH BREEZE","EARTH TONES","LAVENDER HAZE"];

  function hslToHex(h,s,l){s/=100;l/=100;const a=s*Math.min(l,1-l);const f=n=>{const k=(n+h/30)%12;const c=l-a*Math.max(Math.min(k-3,9-k,1),-1);return Math.round(255*c).toString(16).padStart(2,'0')};return`#${f(0)}${f(8)}${f(4)}`.toUpperCase()}
  function generateCohesive7(){const base=Math.random()*360,arr=[];for(let i=0;i<7;i++){const h=(base+(Math.random()*10-5)+360)%360;arr.push(hslToHex(h,40+Math.random()*25,20+i*10))}return arr}

  function renderPalette(cols){
    setCurrentColors(cols);
  }

  function newName(){
    setPaletteName('— • '+NAMES[Math.floor(Math.random()*NAMES.length)]+' • —');
  }

  function generateAndRender(){
    newName();
    renderPalette(generateCohesive7());
  }

  useEffect(()=>{ generateAndRender(); }, []);

  /* Quick View handlers */
  function openQuick(){ setQuickVisible(true); }
  function savePalette(name){
    if (!copiedColors.length) return alert('Copy colors first!');
    const all = JSON.parse(localStorage.getItem('savedPalettes')||'[]');
    all.push({ id: Date.now(), name: name || 'Saved Palette', colors: [...copiedColors], createdAt: new Date().toISOString() });
    localStorage.setItem('savedPalettes', JSON.stringify(all));
    alert('Saved '+(name||'Saved Palette'));
  }

  /* Saved page render */
  function renderSaved() {
    // not reactive view here, saved grid will be read when user navigates to #saved
    const grid = document.getElementById('savedGrid');
    if (!grid) return;
    const all = (JSON.parse(localStorage.getItem('savedPalettes')||'[]')||[]).reverse();
    grid.innerHTML = '';
    if (!all.length) { grid.innerHTML = '<p style="text-align:center">No saved palettes yet.</p>'; return; }
    all.forEach(item=>{
      const card = document.createElement('div'); card.className='saved-card';
      const meta = document.createElement('div');
      meta.innerHTML = `<strong>${item.name}</strong><div style="font-size:12px;color:#6b5b53">${new Date(item.createdAt).toLocaleString()}</div>`;
      const sw = document.createElement('div'); sw.className='saved-swatches';
      item.colors.forEach(hex => {
        const chip = document.createElement('div'); chip.className='chip'; chip.style.background = hex; chip.title = hex;
        chip.onclick = ()=>navigator.clipboard.writeText(hex);
        sw.appendChild(chip);
      });
      const actions = document.createElement('div'); actions.style.display='flex'; actions.style.gap='8px'; actions.style.justifyContent='flex-end';
      const load = document.createElement('button'); load.className='btn btn-outline'; load.textContent='Load';
      load.onclick = ()=>{ document.querySelector('a[href="#home"]').click(); setPaletteName('— • '+item.name+' • —'); renderPalette(item.colors); };
      const del = document.createElement('button'); del.className='btn btn-danger'; del.textContent='Delete';
      del.onclick = ()=>{ if(!confirm('Delete this palette?')) return; const rest = JSON.parse(localStorage.getItem('savedPalettes')||'[]').filter(x=>x.id!==item.id); localStorage.setItem('savedPalettes', JSON.stringify(rest)); renderSaved(); };
      actions.append(load, del);
      card.append(meta, sw, actions); grid.appendChild(card);
    });
  }

  /* Contrast functions */
  function relLum(hex){const n=parseInt(hex.slice(1),16);let r=(n>>16)&255,g=(n>>8)&255,b=n&255;[r,g,b]=[r,g,b].map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return r*.2126+g*.7152+b*.0722}
  function getContrast(a,b){const L1=relLum(a),L2=relLum(b);return (Math.max(L1,L2)+.05)/(Math.min(L1,L2)+.05) }

  /* Upload / K-means */
  function handlePickImage(){ uploadInputRef.current?.click(); }
  function setMsg(t){ setUploadMsg(t); }
  function toHex(r,g,b){ const t = v => Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0'); return ('#'+t(r)+t(g)+t(b)).toUpperCase(); }
  function dist2(a,b){const dr=a[0]-b[0], dg=a[1]-b[1], db=a[2]-b[2]; return dr*dr+dg*dg+db*db;}
  function mean(arr){if(!arr.length)return[0,0,0];let r=0,g=0,b=0;for(const p of arr){r+=p[0];g+=p[1];b+=p[2];}return[r/arr.length,g/arr.length,b/arr.length];}
  function initKMeansPP(data,k){ const n=data.length, centers=[ data[Math.floor(Math.random()*n)] ]; while(centers.length<k){ const dists=data.map(p=>centers.reduce((m,c)=>Math.min(m,dist2(p,c)),Infinity)); const sum=dists.reduce((a,b)=>a+b,0); if(!sum){ while(centers.length<k) centers.push(data[Math.floor(Math.random()*n)]); break; } let r=Math.random()*sum, idx=0; for(let i=0;i<dists.length;i++){ r-=dists[i]; if(r<=0){ idx=i; break; } } centers.push(data[idx]); } return centers.map(c=>[...c]); }
  function kmeans(data, centers, iters){ for(let it=0; it<iters; it++){ const buckets = Array.from({length: centers.length}, ()=>[]); for(const p of data){ let best=0, bestD=Infinity; for(let i=0;i<centers.length;i++){ const d=dist2(p, centers[i]); if(d<bestD){bestD=d; best=i;} } buckets[best].push(p); } for(let i=0;i<centers.length;i++){ if(buckets[i].length) centers[i]=mean(buckets[i]); } } }

  async function handleFileChange(e){
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const link = document.querySelector('a[href="#upload"]'); if (link) link.click();
    setMsg('Reading image…');
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = async () => {
      setMsg('Decoding & sampling…');
      try { if (img.decode) await img.decode(); } catch(_) {}
      const MAX = 320;
      let w = img.naturalWidth || img.width;
      let h = img.naturalHeight || img.height;
      if (!w || !h) { setMsg('Could not read image size. Try PNG/JPG.', false); URL.revokeObjectURL(url); return; }
      const scale = Math.min(1, MAX / Math.max(w, h));
      w = Math.max(1, Math.round(w * scale));
      h = Math.max(1, Math.round(h * scale));
      const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d', { willReadFrequently: true }); ctx.drawImage(img, 0, 0, w, h);
      let data;
      try { const im = ctx.getImageData(0,0,w,h); data = im.data; } catch (err) { setMsg('Browser blocked pixel read. Use local PNG/JPG or serve over http(s).'); URL.revokeObjectURL(url); return; }
      const samples = []; const stride = 4 * 5;
      for (let i = 0; i < data.length; i += stride) {
        const r = data[i], g = data[i+1], b = data[i+2], a = data[i+3];
        if (a < 10) continue;
        samples.push([r,g,b]);
        if (samples.length >= 2500) break;
      }
      if (!samples.length) { setMsg('No visible colors found.', false); URL.revokeObjectURL(url); return; }
      const k = 7, iters = 12;
      const centers = initKMeansPP(samples, k);
      kmeans(samples, centers, iters);
      const hexes = centers.map(c => toHex(c[0], c[1], c[2])).filter((v,i,self)=>self.indexOf(v)===i).slice(0,7);
      if (!hexes.length) { setMsg('Could not extract colors.', false); URL.revokeObjectURL(url); return; }
      setCurrentColors(hexes);
      setMsg(`Extracted ${hexes.length} dominant colors ✔`);
      URL.revokeObjectURL(url);
    };
    img.onerror = () => { setMsg('Could not load this file. Use PNG/JPG/WEBP (HEIC unsupported).', false); URL.revokeObjectURL(url); };
    img.src = url;
  }

  /* Helpers for clipboard + quick view */
  function onSwatchClick(hex){
    navigator.clipboard.writeText(hex);
    setCopiedColors(prev => prev.includes(hex) ? prev : [...prev, hex]);
    alert(hex + ' copied');
  }

  /* when user clicks nav links we may need to refresh saved view */
  useEffect(()=>{
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(a => {
      a.addEventListener('click', ev => {
        ev.preventDefault();
        navLinks.forEach(x=>x.classList.remove('active'));
        a.classList.add('active');
        document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
        const target = document.querySelector(a.getAttribute('href'));
        if (target) target.classList.add('active');
        if (a.getAttribute('href') === '#saved') renderSaved();
      });
    });
    return ()=> navLinks.forEach(a=>a.removeEventListener('click', ()=>{}));
  }, []);

  return (
    <>
      <Header onOpenAuth={() => document.getElementById('authModal')?.classList.add('show')} />
      <div className="toolbar">
        <div className="tool" id="tool-generate" onClick={() => { document.querySelector('a[href="#home"]').click(); generateAndRender(); }}>
          <span>🎨</span><p>Generate</p>
        </div>
        <div className="tool" id="tool-upload" onClick={() => { document.querySelector('a[href="#upload"]').click(); }}>
          <span>🖼</span><p>Upload</p>
        </div>
        <div className="tool" id="tool-contrast" onClick={() => { document.querySelector('a[href="#home"]').click(); setContrastVisible(v=>!v); }}>
          <span>⚖️</span><p>Contrast</p>
        </div>
      </div>

      <main>
        <section id="home" className="page active">
          <h2 style={{textAlign:'center', fontFamily:"'Playfair Display'"}}>Color Palette Inspiration</h2>
          <div id="paletteNameTag" style={{textAlign:'center', margin:'6px', fontSize:13, color:'#6b5b53'}}>{paletteName}</div>
          <div className="controls" style={{textAlign:'center', marginTop:10}}>
            <button id="generateBtn" className="btn btn-primary" onClick={generateAndRender}>Generate Palette</button>
            <button id="copyAllBtn" className="btn btn-outline" onClick={()=>{ if(!currentColors.length) return; navigator.clipboard.writeText(currentColors.join(', ')); alert('All copied!'); }}>Copy All</button>
            <button id="openQuickBtn" className="btn btn-outline" onClick={()=>setQuickVisible(true)}>Quick View</button>
          </div>
          <div id="palette" className="palette" style={{marginTop:12}}>
            {currentColors.map(c=>(
              <div key={c} className="swatch-vertical" style={{background:c}} onClick={()=>onSwatchClick(c)}>
                <div className="hex-chip">{c}</div>
              </div>
            ))}
          </div>

          <div id="quickView" className={`quickview ${quickVisible ? 'show' : ''}`}>
            <h3 style={{textAlign:'center'}}>Quick View — Copied Colors</h3>
            <div id="quickGrid" className="quick-grid">
              {copiedColors.length ? copiedColors.map(c=>(
                <div key={c} className="arc" style={{background:c}} onClick={()=>navigator.clipboard.writeText(c)}>{c}</div>
              )) : <p>No copied colors yet.</p>}
            </div>
            <div className="controls" style={{marginTop:8}}>
              <input id="saveName" className="input" placeholder="Name palette" />
              <button id="saveBtn" className="btn btn-primary" onClick={()=>savePalette(document.getElementById('saveName').value)}>Save Palette</button>
              <button id="closeQuick" className="btn btn-danger" onClick={()=>setQuickVisible(false)}>Close</button>
            </div>
          </div>

          <div id="contrastWrap" className={`contrast ${contrastVisible ? 'show' : ''}`}>
            <h3 style={{textAlign:'center'}}>Contrast Checker</h3>
            <div style={{display:'flex', justifyContent:'center', gap:10, marginTop:10}}>
              <input type="color" id="c1" defaultValue="#222222" />
              <input type="color" id="c2" defaultValue="#ffffff" />
              <button id="checkBtn" className="btn btn-primary" onClick={()=>{
                const c1 = document.getElementById('c1').value;
                const c2 = document.getElementById('c2').value;
                document.getElementById('contrastResult').textContent = 'Contrast ratio: ' + getContrast(c1,c2).toFixed(2) + ' : 1';
              }}>Check</button>
            </div>
            <p id="contrastResult" style={{textAlign:'center', marginTop:8}}></p>
          </div>
        </section>

        <section id="saved" className="page">
          <h2 style={{textAlign:'center'}}>Saved Palettes</h2>
          <div className="controls">
            <button id="refreshSavedBtn" className="btn btn-outline" onClick={renderSaved}>Refresh</button>
            <button id="clearAllSavedBtn" className="btn btn-danger" onClick={()=>{ if(confirm('Clear all saved palettes?')){ localStorage.removeItem('savedPalettes'); renderSaved(); } }}>Clear All</button>
          </div>
          <div id="savedGrid" className="saved-grid"></div>
        </section>

        <section id="upload" className="page">
          <h2 style={{textAlign:'center'}}>Extract From Image</h2>
          <div className="controls">
            <button id="pickImageBtn" className="btn btn-primary" onClick={handlePickImage}>Choose Image</button>
          </div>
          <input ref={uploadInputRef} id="uploadInput" type="file" accept="image/*" style={{display:'none'}} onChange={handleFileChange} />
          <div id="uploadPalette" className="palette" style={{marginTop:12}}>
            {currentColors.map(c=>(
              <div key={'up-'+c} className="swatch-vertical" style={{background:c}} onClick={()=>{ navigator.clipboard.writeText(c); setCopiedColors(prev => prev.includes(c) ? prev : [...prev, c]); setMsg(`${c} copied & added to Quick View.`); }}>
                <div className="hex-chip">{c}</div>
              </div>
            ))}
          </div>
          <div id="uploadMsg" style={{textAlign:'center', marginTop:10}}>{uploadMsg}</div>
        </section>

        <section id="about" className="page">
          <h2 style={{textAlign:'center'}}>About Colorify</h2>
          <div className="about-grid">
            <div className="about-card"><h4>🎨 Smart Generator</h4><p>Creates 7-color harmonious palettes inspired by real trends.</p></div>
            <div className="about-card"><h4>🖼 Image Extraction</h4><p>Automatically finds dominant tones from any image.</p></div>
            <div className="about-card"><h4>⚖️ Contrast Tool</h4><p>Helps ensure accessibility with accurate contrast ratios.</p></div>
            <div className="about-card"><h4>📋 Quick View</h4><p>Preview and copy selected colors in a smooth arc layout.</p></div>
            <div className="about-card"><h4>💾 Save & Reload</h4><p>Store palettes locally and revisit them anytime.</p></div>
            <div className="about-card"><h4>🌸 Aesthetic Design</h4><p>Soft pastels and minimal UI ideal for designers.</p></div>
          </div>
        </section>

        <section id="contact" className="page">
          <h2 style={{textAlign:'center'}}>Contact</h2>
          <div className="contact">
            <p>📧 Email: <a href="mailto:rashipande05@gmail.com">rashipande05@gmail.com</a></p>
            <p>💼 LinkedIn: <a href="https://www.linkedin.com/in/rashi-pande-84325726a" target="_blank">Rashi Pande</a></p>
            <hr/>
            <form onSubmit={(e)=>{ e.preventDefault(); alert('Thank you for reaching out!'); }}>
              <input className="input" placeholder="Name" style={{display:'block',width:'100%',margin:'8px 0'}}/>
              <input className="input" placeholder="Email" style={{display:'block',width:'100%',margin:'8px 0'}}/>
              <textarea className="input" placeholder="Message..." style={{display:'block',width:'100%',margin:'8px 0'}}/>
              <button className="btn btn-primary" style={{marginTop:6}}>Send</button>
            </form>
          </div>
        </section>
      </main>

      <footer>© 2025 Colorify — Create, Save & Inspire</footer>

      {/* Auth Modal (mock) */}
      <div id="authModal" className="auth-modal">
        <div className="auth-box">
          <h3 id="authTitle">Login</h3>
          <input id="authName" placeholder="Name (signup)" className="hidden" />
          <input id="authEmail" placeholder="Email" />
          <input id="authPass" type="password" placeholder="Password" />
          <div style={{display:'flex', gap:8}}>
            <button id="authSubmit" className="btn btn-primary" onClick={()=>{
              const em = document.getElementById('authEmail').value;
              const pw = document.getElementById('authPass').value;
              if(!em||!pw) return alert('Enter credentials');
              // mock local auth for UI demo
              localStorage.setItem('user', JSON.stringify({ email: em }));
              document.getElementById('authModal').classList.remove('show');
              alert('Logged in (mock)');
              window.location.reload();
            }}>Login</button>
            <button id="authToggle" className="btn btn-outline" onClick={()=>{
              const nameEl = document.getElementById('authName');
              const title = document.getElementById('authTitle');
              const toggle = document.getElementById('authToggle');
              const submit = document.getElementById('authSubmit');
              const isSignup = !nameEl.classList.contains('hidden');
              nameEl.classList.toggle('hidden', isSignup);
              title.textContent = isSignup ? 'Login' : 'Sign Up';
              submit.textContent = isSignup ? 'Login' : 'Sign Up';
              toggle.textContent = isSignup ? 'Don’t have an account? Sign up' : 'Already have an account? Login';
            }}>Don’t have an account? Sign up</button>
          </div>
          <button id="authClose" className="btn btn-danger" onClick={()=>document.getElementById('authModal').classList.remove('show')}>Close</button>
        </div>
      </div>
    </>
  );
}