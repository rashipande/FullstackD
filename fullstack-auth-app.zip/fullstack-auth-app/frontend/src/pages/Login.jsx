import React, { useState, useContext } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function Login(){
  const [email,setEmail]=useState(''); const [pass,setPass]=useState('');
  const { login } = useContext(AuthContext);
  const nav = useNavigate();
  const submit = async (e) => {
    e.preventDefault();
    try { await login(email, pass); nav('/'); } catch (err) { alert(err.response?.data?.message || 'Login failed'); }
  };
  return (
    <div style={{padding:20}}>
      <h2>Login</h2>
      <form onSubmit={submit}>
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
        <input placeholder="Password" type="password" value={pass} onChange={e=>setPass(e.target.value)} /><br/>
        <button type="submit">Login</button>
      </form>
      <p><Link to="/signup">Create account</Link></p>
    </div>
  );
}