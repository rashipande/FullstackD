import React, { useState, useContext } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function Signup(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [pass,setPass]=useState('');
  const { signup } = useContext(AuthContext);
  const nav = useNavigate();
  const submit = async (e) => {
    e.preventDefault();
    try { await signup(name, email, pass); nav('/'); } catch (err) { alert(err.response?.data?.message || 'Signup failed'); }
  };
  return (
    <div style={{padding:20}}>
      <h2>Sign up</h2>
      <form onSubmit={submit}>
        <input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} /><br/>
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
        <input placeholder="Password" type="password" value={pass} onChange={e=>setPass(e.target.value)} /><br/>
        <button type="submit">Sign up</button>
      </form>
      <p><Link to="/login">Already have an account?</Link></p>
    </div>
  );
}