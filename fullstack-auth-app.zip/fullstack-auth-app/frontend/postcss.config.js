module.exports = {
  plugins: {
    autoprefixer: {}
  }
};